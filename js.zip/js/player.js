/**
 * Rugged Music Player - Player Logic Module
 * Controls core audio element events, state machine (play/pause/skip),
 * shuffle/loop queues, volume persistence, and Blob Object URL lifecycle management.
 * Extended with dual-playback engine support: HTML5 Audio + YouTube IFrame API!
 * Global namespace version for file:// protocol compatibility.
 * Race-Condition Resolved Edition.
 */

let audio = null;
let currentTrack = null;
let currentObjectUrl = null;

// Playback Queue State
let originalQueue = []; 
let activeQueue = [];   
let currentQueueIndex = -1;

// Configuration States
let isPlaying = false;
let isShuffle = false;
let isLoop = 'none'; // 'none' | 'queue' | 'track'

// Dual Playback Engine States
let activeEngine = 'local'; // 'local' | 'youtube'
let ytPlayer = null;
let ytInterval = null;
let isYtApiReady = false;

// Persistence keys
const LOCAL_STORAGE_VOL_KEY = 'rugged-player-volume';

// Callback registry for UI updates
const callbacks = {
    onTrackChange: () => {},
    onPlayStateChange: () => {},
    onTimeUpdate: () => {},
    onQueueChange: () => {},
    onProgressUpdate: () => {}
};

/**
 * STATIC GLOBAL CALLBACK FOR YOUTUBE IFRAME API
 * Defined immediately in the global scope to eliminate load order race conditions.
 * Executes as soon as the YouTube API script is loaded and running.
 */
window.onYouTubeIframeAPIReady = () => {
    isYtApiReady = true;
    
    // Safely waits for DOM elements to exist before initializing the YouTube IFrame player
    const initYtPlayer = () => {
        const container = document.getElementById('youtube-player-iframe');
        if (!container) {
            // Target container does not exist yet, defer until DOMContentLoaded
            document.addEventListener('DOMContentLoaded', initYtPlayer);
            return;
        }
        
        try {
            ytPlayer = new YT.Player('youtube-player-iframe', {
                height: '100%',
                width: '100%',
                videoId: '',
                playerVars: {
                    'playsinline': 1,
                    'controls': 0,
                    'disablekb': 1,
                    'fs': 0,
                    'modestbranding': 1,
                    'rel': 0,
                    'autoplay': 0
                    'origin': window.location.origin
                },
                events: {
                    'onReady': (event) => {
                        // Sync saved volume state
                        const savedVolume = localStorage.getItem(LOCAL_STORAGE_VOL_KEY);
                        const startVolume = savedVolume !== null ? parseFloat(savedVolume) : 0.8;
                        event.target.setVolume(startVolume * 100);
                    },
                    'onStateChange': handleYouTubeStateChange,
                    'onError': (e) => {
                        console.error('YouTube player error:', e.data);
                        if (activeEngine === 'youtube') {
                            setTimeout(() => nextTrack(), 2000);
                        }
                    }
                }
            });
        } catch (e) {
            console.error('Failed to instantiate YT.Player:', e);
        }
    };
    
    initYtPlayer();
};

/**
 * Initializes the audio player engine.
 * Binds HTML5 audio events and loads the YouTube IFrame Player API.
 * @param {HTMLAudioElement} audioElement 
 * @param {Object} customCallbacks 
 */
function initPlayer(audioElement, customCallbacks = {}) {
    audio = audioElement;
    
    // Bind callbacks
    Object.assign(callbacks, customCallbacks);

    // Load saved volume (default to 0.8)
    const savedVolume = localStorage.getItem(LOCAL_STORAGE_VOL_KEY);
    const initialVolume = savedVolume !== null ? parseFloat(savedVolume) : 0.8;
    audio.volume = initialVolume;

    // Bind HTML5 Audio Element Events
    audio.addEventListener('timeupdate', () => {
        if (activeEngine === 'local' && audio.duration) {
            callbacks.onTimeUpdate(audio.currentTime, audio.duration);
        }
    });

    audio.addEventListener('ended', () => {
        if (activeEngine === 'local') {
            handleTrackEnded();
        }
    });

    audio.addEventListener('error', (e) => {
        if (activeEngine === 'local') {
            console.error('Local Audio playback error:', e);
            setTimeout(() => nextTrack(), 2000);
        }
    });

    // Initiate YouTube API script load
    injectYouTubeScript();
}

/**
 * Loads the YouTube IFrame API script dynamically.
 */
function injectYouTubeScript() {
    if (document.getElementById('youtube-iframe-api-script')) {
        return;
    }

    const tag = document.createElement('script');
    tag.id = 'youtube-iframe-api-script';
    tag.src = "https://www.youtube.com/iframe_api";
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
}

/**
 * Handles YouTube IFrame state change updates.
 * @param {Object} event 
 */
function handleYouTubeStateChange(event) {
    if (activeEngine !== 'youtube') return;

    const state = event.data;

    // YT.PlayerState codes:
    // -1 = unstarted, 0 = ended, 1 = playing, 2 = paused, 3 = buffering, 5 = cued
    if (state === YT.PlayerState.PLAYING) {
        isPlaying = true;
        callbacks.onPlayStateChange(isPlaying);
        startYouTubeTimePoller();
    } else if (state === YT.PlayerState.PAUSED) {
        isPlaying = false;
        callbacks.onPlayStateChange(isPlaying);
        stopYouTubeTimePoller();
    } else if (state === YT.PlayerState.ENDED) {
        stopYouTubeTimePoller();
        handleTrackEnded();
    }
}

/**
 * Starts a 250ms polling timer to simulate timeupdate events for YouTube player.
 */
function startYouTubeTimePoller() {
    stopYouTubeTimePoller();
    ytInterval = setInterval(() => {
        if (ytPlayer && ytPlayer.getCurrentTime && ytPlayer.getDuration) {
            const currentTime = ytPlayer.getCurrentTime() || 0;
            const duration = ytPlayer.getDuration() || 0;
            if (duration > 0) {
                callbacks.onTimeUpdate(currentTime, duration);
            }
        }
    }, 250);
}

/**
 * Stops the YouTube polling timer.
 */
function stopYouTubeTimePoller() {
    if (ytInterval) {
        clearInterval(ytInterval);
        ytInterval = null;
    }
}

/**
 * Updates the current queue of playable tracks.
 * @param {Array<Object>} newQueue - List of track metadata objects
 * @param {string} startWithTrackId - Optional track ID to immediately play
 */
async function updateQueue(newQueue, startWithTrackId = null) {
    originalQueue = [...newQueue];
    
    if (isShuffle) {
        activeQueue = shuffleArray([...originalQueue]);
    } else {
        activeQueue = [...originalQueue];
    }

    callbacks.onQueueChange(activeQueue);

    if (startWithTrackId) {
        const index = activeQueue.findIndex(t => t.id === startWithTrackId);
        if (index !== -1) {
            await loadAndPlay(index);
        }
    } else if (currentTrack) {
        currentQueueIndex = activeQueue.findIndex(t => t.id === currentTrack.id);
    }
}

/**
 * Loads a track from database by index in the active queue, and starts playback.
 * Automatically toggles between HTML5 Audio and YouTube engines!
 * @param {number} index 
 */
async function loadAndPlay(index) {
    if (index < 0 || index >= activeQueue.length) return;
    
    currentQueueIndex = index;
    const trackMetadata = activeQueue[index];

    try {
        // Fetch track details from DB via global window.RuggedDB
        const fullTrack = await window.RuggedDB.getTrack(trackMetadata.id);
        if (!fullTrack) {
            throw new Error(`Track metadata not found for ID: ${trackMetadata.id}`);
        }

        // TAPE SELECTION ROUTER
        if (fullTrack.isYouTube) {
            // --- YOUTUBE ENGINE ROUTING ---
            activeEngine = 'youtube';
            
            // Pause and clear HTML5 Audio player
            audio.pause();
            audio.src = '';
            if (currentObjectUrl) {
                URL.revokeObjectURL(currentObjectUrl);
                currentObjectUrl = null;
            }

            // Sync visualizer to synthetic pulsing spectrum
            if (window.RuggedVisualizer) {
                window.RuggedVisualizer.setYouTubeMode(true);
            }

            currentTrack = fullTrack;
            callbacks.onTrackChange(currentTrack);

            // Load and play inside YouTube IFrame Player
            if (ytPlayer && ytPlayer.loadVideoById) {
                isPlaying = true;
                callbacks.onPlayStateChange(isPlaying);
                
                // Show the YouTube monitor pane (VFD-bordered window in HTML)
                const ytScreen = document.getElementById('youtube-monitor-panel');
                if (ytScreen) {
                    ytScreen.style.display = 'block';
                }

                ytPlayer.loadVideoById(fullTrack.youtubeId);
            } else {
                console.warn('YouTube IFrame Player is not ready yet. Retrying in 1s...');
                setTimeout(() => loadAndPlay(index), 1000);
            }

        } else {
            // --- LOCAL AUDIO ENGINE ROUTING ---
            activeEngine = 'local';

            // Stop and hide YouTube player
            stopYouTubeTimePoller();
            if (ytPlayer && ytPlayer.pauseVideo) {
                ytPlayer.pauseVideo();
            }
            const ytScreen = document.getElementById('youtube-monitor-panel');
            if (ytScreen) {
                ytScreen.style.display = 'none';
            }

            // Sync visualizer to use physical sound card frequencies
            if (window.RuggedVisualizer) {
                window.RuggedVisualizer.setYouTubeMode(false);
            }

            if (!fullTrack.file) {
                throw new Error(`Track Blob missing for local ID: ${fullTrack.id}`);
            }

            // Revoke old object URL
            if (currentObjectUrl) {
                URL.revokeObjectURL(currentObjectUrl);
            }

            // Create new Blob URL
            currentObjectUrl = URL.createObjectURL(fullTrack.file);
            
            currentTrack = fullTrack;
            audio.src = currentObjectUrl;
            
            callbacks.onTrackChange(currentTrack);
            await playTrack();
        }

    } catch (err) {
        console.error('Failed to load track:', err);
    }
}

/**
 * Play current track.
 */
async function playTrack() {
    if (activeEngine === 'local') {
        if (!audio.src) {
            if (activeQueue.length > 0) await loadAndPlay(0);
            return;
        }
        try {
            isPlaying = true;
            callbacks.onPlayStateChange(isPlaying);
            await audio.play();
        } catch (e) {
            console.warn('Local playback failed/requires gesture:', e);
            isPlaying = false;
            callbacks.onPlayStateChange(isPlaying);
        }
    } else if (activeEngine === 'youtube') {
        if (ytPlayer && ytPlayer.playVideo) {
            ytPlayer.playVideo();
        }
    }
}

/**
 * Pause current track.
 */
function pauseTrack() {
    if (activeEngine === 'local') {
        audio.pause();
        isPlaying = false;
        callbacks.onPlayStateChange(isPlaying);
    } else if (activeEngine === 'youtube') {
        if (ytPlayer && ytPlayer.pauseVideo) {
            ytPlayer.pauseVideo();
        }
    }
}

/**
 * Toggle between Play and Pause.
 */
function togglePlay() {
    if (isPlaying) {
        pauseTrack();
    } else {
        playTrack();
    }
}

/**
 * Jump to the next track.
 */
async function nextTrack() {
    if (activeQueue.length === 0) return;

    let nextIndex = currentQueueIndex + 1;
    if (nextIndex >= activeQueue.length) {
        nextIndex = 0;
    }

    await loadAndPlay(nextIndex);
}

/**
 * Jump to the previous track.
 */
async function prevTrack() {
    if (activeQueue.length === 0) return;

    let prevIndex = currentQueueIndex - 1;
    if (prevIndex < 0) {
        prevIndex = activeQueue.length - 1;
    }

    await loadAndPlay(prevIndex);
}

/**
 * Handles automatic queue progression.
 */
function handleTrackEnded() {
    if (isLoop === 'track') {
        if (activeEngine === 'local') {
            audio.currentTime = 0;
            playTrack();
        } else if (activeEngine === 'youtube' && ytPlayer && ytPlayer.seekTo) {
            ytPlayer.seekTo(0, true);
            ytPlayer.playVideo();
        }
    } else if (isLoop === 'queue') {
        nextTrack();
    } else {
        if (currentQueueIndex < activeQueue.length - 1) {
            nextTrack();
        } else {
            pauseTrack();
            if (activeEngine === 'local') {
                audio.currentTime = 0;
            } else if (activeEngine === 'youtube' && ytPlayer && ytPlayer.seekTo) {
                ytPlayer.seekTo(0, true);
            }
        }
    }
}

/**
 * Seeks playback position.
 * @param {number} percent - Position from 0 to 1
 */
function seekTo(percent) {
    if (activeEngine === 'local') {
        if (!audio.duration) return;
        audio.currentTime = audio.duration * percent;
    } else if (activeEngine === 'youtube') {
        if (ytPlayer && ytPlayer.getDuration && ytPlayer.seekTo) {
            const duration = ytPlayer.getDuration();
            ytPlayer.seekTo(duration * percent, true);
        }
    }
}

/**
 * Sets playback volume and persists it.
 * @param {number} volume - From 0.0 to 1.0
 */
function setVolume(volume) {
    const val = Math.max(0, Math.min(1, volume));
    
    audio.volume = val;
    
    if (ytPlayer && ytPlayer.setVolume) {
        ytPlayer.setVolume(val * 100);
    }
    
    localStorage.setItem(LOCAL_STORAGE_VOL_KEY, val);
}

/**
 * Gets current volume.
 * @returns {number}
 */
function getVolume() {
    return audio ? audio.volume : 0.8;
}

/**
 * Toggles shuffle mode.
 */
function toggleShuffle() {
    isShuffle = !isShuffle;
    
    if (isShuffle && originalQueue.length > 0) {
        const trackId = currentTrack ? currentTrack.id : null;
        let pool = [...originalQueue];
        
        if (trackId) {
            pool = pool.filter(t => t.id !== trackId);
            activeQueue = [currentTrack, ...shuffleArray(pool)];
            currentQueueIndex = 0;
        } else {
            activeQueue = shuffleArray(pool);
            currentQueueIndex = -1;
        }
    } else {
        activeQueue = [...originalQueue];
        if (currentTrack) {
            currentQueueIndex = activeQueue.findIndex(t => t.id === currentTrack.id);
        }
    }

    callbacks.onQueueChange(activeQueue);
    return isShuffle;
}

/**
 * Toggles loop mode.
 */
function toggleLoop() {
    if (isLoop === 'none') {
        isLoop = 'queue';
    } else if (isLoop === 'queue') {
        isLoop = 'track';
    } else {
        isLoop = 'none';
    }
    return isLoop;
}

/**
 * Utility to shuffle an array.
 * @param {Array} array 
 * @returns {Array}
 */
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Getters for player state
function getPlayerState() {
    return {
        currentTrack,
        isPlaying,
        isShuffle,
        isLoop,
        activeQueue,
        currentQueueIndex,
        activeEngine
    };
}

// Expose to global namespace
window.RuggedPlayer = {
    initPlayer,
    updateQueue,
    playTrack,
    pauseTrack,
    togglePlay,
    nextTrack,
    prevTrack,
    seekTo,
    setVolume,
    getVolume,
    toggleShuffle,
    toggleLoop,
    getPlayerState
};
